## Module <pos_discount_manager>

#### 12.05.2023
#### Version 16.0.1.0.0
#### ADD
- Initial Commit  POS Discount Manager Approval

#### 21.07.2023
#### Version 16.0.2.0.1
#### FIX
- Removed the already existing function from payment screen js function. 
- Super the existing button action.

#### 20.11.2023
#### Version 16.0.2.0.2
#### UPDATE
- Manager Pin Encrypted in NumberPad.
- Changed Pin Condition Check from Top Sequence Manager to Session Manager.

#### 08.12.2023
#### Version 16.0.2.0.3
#### UPDATE
- Changed Pin Condition Check from Session Manager to All Managers that are Selected in Multi Employee Section.
