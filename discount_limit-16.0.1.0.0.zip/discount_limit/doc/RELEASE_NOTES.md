## Module <discount_limit>

#### 28.01.2024
#### Version 16.0.1.0.0
##### ADD
- Initial Commit for POS Discount Limit & Restrict Global Discount
