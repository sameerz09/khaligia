## Module <multi_currency_payment_in_pos>

#### 27.11.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for POS Multi Currency Payment


#### 18.07.2024
#### Version 16.0.1.0.0
#### BUG FIX

- The multicurrency is enabled before session opened.Once the session open we can't change the options.

