## Module <pos_controlled_interface>

#### 02.12.2023
#### Version 16.0.1.0.0
##### ADD
- Initial Commit for Controlled Point Of Sale
 