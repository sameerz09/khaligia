## Module <pos_zero_quantity_restrict>

#### 20.06.2023
#### Version 16.0.1.0.0
#### ADD
 - Initial Commit for POS Restriction For Zero Quantity.