## Module <pos_customer_birthday_discount>

#### 31.08.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for POS Birthday Discount
