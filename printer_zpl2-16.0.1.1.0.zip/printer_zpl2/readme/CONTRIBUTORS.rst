* Sylvain Garancher <sylvain.garancher@syleam.fr>
* Florent de Labarre
* Jos De Graeve <Jos.DeGraeve@apertoso.be>
* Rod Schouteden <rod.schouteden@dynapps.be>
* Miquel Raïch <miquel.raich@forgeflow.com>
* Lois Rilo <lois.rilo@forgeflow.com>
* Tran Quoc Duong <duontq@trobz.com>
