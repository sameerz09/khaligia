## Module <custom_receipts_for_pos>

#### 21.11.2022
#### Version 16.0.1.0.0
#### ADD
Initial Commit for POS Receipt Designs.


#### 06.09.2024
#### Version 16.0.1.0.1
#### BUGFIX
- Fixed the missing company logo in the pos receipts when printing.
