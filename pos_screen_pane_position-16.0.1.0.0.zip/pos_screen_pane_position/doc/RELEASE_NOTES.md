## Module <pos_screen_pane_position>

#### 18.11.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Screen Positions in POS