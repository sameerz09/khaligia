## Module <pos_receipt_invoice_send_whatsapp>

#### 12.06.2024

#### Version 17.0.1.0.0

##### ADD

- Initial commit for Send POS Receipt and Invoice via WhatsApp

## Module <pos_receipt_invoice_send_whatsapp>

#### 05.09.2024

#### Version 17.0.1.0.0

##### ADD

- Updated the module: Encountered a null case when no customer is selected. Fixed the error by checking null case in
  receipt and payment screen.
