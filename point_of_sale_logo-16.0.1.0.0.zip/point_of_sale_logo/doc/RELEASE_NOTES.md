## Module <point_of_sale_logo>

#### 5.12.2022
#### Version 16.0.1.0.0
#### ADD
Initial commit for Point of Sale Logo



